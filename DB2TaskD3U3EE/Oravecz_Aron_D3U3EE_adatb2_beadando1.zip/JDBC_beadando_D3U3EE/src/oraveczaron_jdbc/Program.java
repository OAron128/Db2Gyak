package oraveczaron_jdbc;


public class Program {
	static DbMethods dbm = new DbMethods();
	
	public static void main(String[] args) {
		
		dbm.DriverReg();
		
		int k = dbm.LogIn();
		do{
			if (k == 1)
			{
				System.out.println("Sikeres bejelentkez�s!");
			}
			else {
				k = dbm.LogIn();
				if(k == 1) System.out.println("\nSikeres bejelentkez�s!");
			}
		}while(k != 1);
		while (1 != 0) {
			dbm.menu();
		}
		
		/*
		//T�bl�k l�trehoz�sa
		String sqlp="CREATE TABLE Szekhely (Tid INT PRIMARY KEY, Irsz INT,"+"Varos CHAR(30), Utca CHAR(30), Hazszam NUMBER(10))";
		dbm.ParancsExec(sqlp);
		*/
		
		/*
		String sqlp="CREATE TABLE Fogyasztok (Fid INT PRIMARY KEY, Szulonev CHAR(30),"+"Gyermeknev CHAR(30), Foglalkozas CHAR(30),Diakigazolvany NUMBER(11))";
		dbm.ParancsExec(sqlp);
		*/
		
		/*
		String sqlp="CREATE TABLE Ceg (Cid INT PRIMARY KEY, Tid INT,"+"Fid INT, Nev CHAR(30), Alapitas_eve DATE, FOREIGN KEY(Tid) REFERENCES Szekhely(Tid), FOREIGN KEY(Tid) REFERENCES Fogyasztok(Fid) )";
		dbm.ParancsExec(sqlp);
		*/
		/*
		String sqlp="INSERT INTO Szekhely VALUES(1, 1027, 'Budapest', 'P�k�sz utca','7')";
		dbm.ParancsExec(sqlp);
		
		String sqlp="INSERT INTO Szekhely VALUES(2, 4080, 'Hajdun�n�s', 'H�s�k �t','18')";
		dbm.ParancsExec(sqlp);
		
		String sqlp="INSERT INTO Szekhely VALUES(3, 3530, 'Miskolc', 'J�zsef Attila �t','40')";
		dbm.ParancsExec(sqlp);
		
		String sqlp="INSERT INTO Szekhely VALUES(4, 1043, 'T�rnok', 'Bessenyei �t','1')";
		dbm.ParancsExec(sqlp);
		
		String sqlp="INSERT INTO Szekhely VALUES(5, 2076, 'Sopron', 'Pet�fi utca','88')";
		dbm.ParancsExec(sqlp);
		*/
		/*
		String sqlp ="INSERT INTO Fogyasztok VALUES (1, 'Brask� P�ter', 'Brask� �ron', 'Programoz�s', '7417175879')";
		dbm.ParancsExec(sqlp);
		
		
		String sqlp ="INSERT INTO Fogyasztok VALUES (2, 'Sz�sz R�jna', 'Farkas �kos', 'Villamosm�rn�k', '7417175321')";
		dbm.ParancsExec(sqlp);
		
		String sqlp ="INSERT INTO Fogyasztok VALUES (3, 'Kov�cs Anett', 'T�th J�zsef', 'Rendszerm�rn�k', '7417175765')";
		dbm.ParancsExec(sqlp);
		
	
		String sqlp ="INSERT INTO Fogyasztok VALUES (4, 'Puszta Tam�s', 'Puszta Ildik�', 'Jog�sz', '7417175435')";
		dbm.ParancsExec(sqlp);
		
		String sqlp ="INSERT INTO Fogyasztok VALUES (5, 'R�ti Norbert', 'R�ti Mih�ly', 'Orvos', '7417175545')";
		dbm.ParancsExec(sqlp);
		*/
		
		/*
		String sqlp ="INSERT INTO Fogyasztok VALUES (6, 'Mez� Pista', 'Mez� G�za', 'Programoz�s', '7417175546')";
		dbm.ParancsExec(sqlp);
		*/
		
		/*
		String sqlp ="INSERT INTO Ceg VALUES (1, 1, 1,'Logiscool', TO_DATE('20080521','YYYYMMDD'))";
		dbm.ParancsExec(sqlp);
		
		String sqlp ="INSERT INTO Ceg VALUES (2, 2, 4,'JogiSchool', TO_DATE('20101225','YYYYMMDD'))";
		dbm.ParancsExec(sqlp);
		
		String sqlp ="INSERT INTO Ceg VALUES (3, 3, 5,'Ment�TisztiDE', TO_DATE('20101225','YYYYMMDD'))";
		dbm.ParancsExec(sqlp);
		
		String sqlp ="INSERT INTO Ceg VALUES (4, 4, 2,'MavirDK', TO_DATE('20010120','YYYYMMDD'))";
		dbm.ParancsExec(sqlp);
		
		String sqlp ="INSERT INTO Ceg VALUES (5, 5, 3,'Rendszer�zemSchool', TO_DATE('20200309','YYYYMMDD'))";
		dbm.ParancsExec(sqlp);
		*/
		
		/*String sqlp = "CREATE TABLE Bejelentkezes (felhasznalonev char(20) primary key, jelszo char(30))";
		dbm.ParancsExec(sqlp);
		sqlp = "INSERT INTO Bejelentkezes values ('evelin02', 'kiskutya777')";
		dbm.ParancsExec(sqlp);
		sqlp = "INSERT INTO Bejelentkezes values ('lilapamacs11', 'plplplpl')";			
		dbm.ParancsExec(sqlp);
		sqlp = "INSERT INTO Bejelentkezes values ('felhaszn�l�n�v', 'jelsz�')";
		dbm.ParancsExec(sqlp);
		sqlp = "INSERT INTO Bejelentkezes values ('useruser', 'passwdpasswd')";
		dbm.ParancsExec(sqlp);
		sqlp = "INSERT INTO Bejelentkezes values ('user', 'passwd')";
		dbm.ParancsExec(sqlp);*/

	}

}
