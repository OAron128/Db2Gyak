package oraveczaron_jdbc;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DbMethods {
	static Connection conn = null;
	//Sz�ks�ges met�dusok 
			//Driver regisztr�ci�
			//Kapcsolo�d�s
			//Lekapcsol�d�s
			//Lek�rdez�s
			//Besz�r�s
			//T�rl�s
			//M�dos�t�s
			
	public static void DriverReg() { //Driver regisztr�ci�
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//System.out.println("Sikeres driver regisztr�l�s\n");
		} catch (Exception ex) {
			System.err.println(ex.getMessage());
		}
	}
	
	public Connection Connect(){ //Kapcsol�d�s �s Bejelentkez�s
		Connection conn =null;
		String url = "jdbc:oracle:thin:@193.6.5.58:1521:XE";
		String user = "H22_d3u3ee";
		String pwd = "D3U3EE";
		try {
			conn =  DriverManager.getConnection(url, user, pwd);
			//System.out.println("Sikeres kapcsol�d�s\n");
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return conn;
	}
	
	public void DisConnect(Connection conn) { //Lekapcsol�d�s
		if (conn != null) {
			try {
				conn.close();
				//System.out.println("Sikeres lekapcsol�d�s\n");
			} catch (Exception ex) {
				System.err.println(ex.getMessage());
			}
		}
	}
	
	public void ParancsExec(String command) {  //"egyir�ny�" parancsok kiad�sa Statment egyszer�s�t�se
		Connection conn = Connect();
		String sqlp = command;
		//System.out.println("Parancs: "+sqlp);
		try {
			Statement s = conn.createStatement();
			s.execute(sqlp);
			//System.out.println(sqlp+"\n");
			//System.out.println("Sikeres Parancs");
		} catch(SQLException e) {
			System.out.println("ParancsExec: "+e.getMessage());
		}
		DisConnect(conn);
	}
	
	
	/*
	public void ReadDataFogyaszto() {
		String Sznev="", Gynev="", Foglalkozas="",x="\t";
		int Fid=0, Digazolvany=0;
		
		String sqlp="SELECT Fid, Sznev, Gynev, Foglalkozas, Digazolvany FROM Fogyasztok";
		Connection conn = Connect();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sqlp);
			while(rs.next()) {
				Fid= rs.getInt("Fid");
				Sznev = rs.getString("Szulonev");  //Adatok beolvas�sa rekordonk�nt ciklusba
				Gynev = rs.getString("Gyermeknev");
				Foglalkozas = rs.getString("Foglalkozas");
				Digazolvany= rs.getInt("Diakigazolvany"); //ITT A PROBLEM
				System.out.println(Fid+x+Sznev+x+Gynev+x+Foglalkozas+x+Digazolvany); //kiir�s
			}
			rs.close();
		}catch(SQLException e) {
			System.out.println("ReadDataFogyaszto: "+e.getMessage());
		}
		DisConnect(conn);
	}
	
	public void ReadDataCeg() {
		String Nev="", x="\t";
		int Cid=0,Fid=0, Tid=0;
		Date Alapitas;
		String sqlp="SELECT Cid, Fid, Tid, Nev,Alapitas FROM Ceg";
		Connection conn = Connect();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sqlp);
			while(rs.next()) {
				Cid= rs.getInt("Cid");
				Fid= rs.getInt("Fid");
				Tid= rs.getInt("Tid");
				Nev = rs.getString("Szulonev");  //Adatok beolvas�sa rekordonk�nt ciklusba
				Alapitas = rs.getDate("Alapitas_eve");
			
				System.out.println(Cid+x+Fid+x+Tid+x+Nev+x+Alapitas); //kiir�s
			}
			rs.close();
		}catch(SQLException e) {
			System.out.println("ReadDataCeg: "+e.getMessage());
		}
		DisConnect(conn);
	}
	*/
	
	public int LogIn() {
		int in = 0, check = 0;
		String user = null, passwd = null;
		Connection conn = Connect();

		
		user = ReadData("Van m�r fi�kod? (igen/nem)");
		if(user.equals("igen"))
		{try {
			Statement s = conn.createStatement();
			do{
				user = ReadData("Felhaszn�l�n�v: ");
				check = s.executeUpdate("SELECT felhasznalonev FROM Bejelentkezes WHERE felhasznalonev = '" + user + "'");
				if(check == 0) System.out.println("Ilyen felhaszn�l�n�vvel nem l�tezik felhaszn�l�!");
			}while(check != 1);
			do {
				passwd = ReadData("Jelsz�: ");
				check = s.executeUpdate("SELECT felhasznalonev, jelszo FROM Bejelentkezes WHERE felhasznalonev = '" + user + "' AND jelszo = '" + passwd + "'");
				if(check == 0) System.out.println("Hib�s jelsz�!");
			}while(check != 1);
			in = 1;
			return in;
		}catch(SQLException e) {
			System.out.println("JDBC Bejelentkezes: " + e.getMessage());
		}}
		else if(user.equals("nem"))
		{
			String reg = ReadData("Szeretn�l regisztr�lni? (igen/nem)");
			if(reg.equals("nem"))
			{
				System.out.println("Rendben, viszl�t!");
				System.exit(0);
			}
			else if(reg.equals("igen")) {
				int jo = 0;
			try {
				Statement s = conn.createStatement();
				do{
					user = ReadData("Adj meg egy felhaszn�l�nevet: ");
					jo = s.executeUpdate("SELECT felhasznalonev FROM Bejelentkezes WHERE felhasznalonev = '" + user + "'");
					if(jo != 0) System.out.println("Ez a felhaszn�l�n�v m�r foglalt!");
				}while(jo!=0);
				
				do{
					passwd = ReadData("Adj meg egy jelsz�t: ");
					String passwd2 = ReadData("Add meg �jra a jelszavadat: ");
					if (passwd.equals(passwd2))
					{
						ParancsExec("INSERT INTO Bejelentkezes VALUES ('" + user + "', '" + passwd + "')");
						jo = 1;
						System.out.println("Sikeres regisztr�ci�!");
					}
					else System.out.println("Nem egyezik a k�t jelsz�!");
				}while(jo != 1);
				return in;
				
			}catch(SQLException e) {
				System.out.println("Regisztracio: " + e.getMessage());
			}
			}
		}	return in;
	}
	
	public String ReadData(String s) {
		Scanner scanInput = new Scanner(System.in);
		String data = "";
		System.out.println(s);
		data = scanInput.nextLine();
		return data;
	}
	
	public int ReadInt(String s) {
		Scanner scanInput = new Scanner(System.in);
		int data = -1;
		System.out.println(s);
		data = scanInput.nextInt();
		return data;
	}


	public void ReadDataCeg() {
		String Nev="", x="\t";
		int Cid=0,Fid=0, Tid=0;
		Date Alapitas;
		String sqlp="SELECT Cid, Fid, Tid, Nev, Alapitas_eve FROM Ceg";
		Connection conn = Connect();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sqlp);
			while(rs.next()) {
				Cid= rs.getInt("Cid");
				Fid= rs.getInt("Fid");
				Tid= rs.getInt("Tid");
				Nev = rs.getString("Nev");  //Adatok beolvas�sa rekordonk�nt ciklusba
				Alapitas = rs.getDate("Alapitas_eve");
			
				System.out.println(Cid+x+Fid+x+Tid+x+Nev+x+Alapitas); //kiir�s
			}
			rs.close();
		}catch(SQLException e) {
			System.out.println("ReadDataCeg: "+e.getMessage());
		}
		DisConnect(conn);
	}
	
	public void ReadDataFogyaszto() {
		String Sznev="", Gynev="", Foglalkozas="",x="\t";
		int Fid=0;
		long Digazolvany=0;
		
		String sqlp="SELECT Fid, Szulonev, Gyermeknev, Foglalkozas, Diakigazolvany FROM Fogyasztok";
		//CommandExec(sqlp);
		Connection conn = Connect();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sqlp);
			while(rs.next()) {
				Fid= rs.getInt("Fid");
				Sznev = rs.getString("Szulonev");  //Adatok beolvas�sa rekordonk�nt ciklusba
				Gynev = rs.getString("Gyermeknev");
				Foglalkozas = rs.getString("Foglalkozas");
				Digazolvany= rs.getLong("Diakigazolvany"); //ITT A PROBLEM
				System.out.println(Fid+x+Sznev+x+Gynev+x+Foglalkozas+x+Digazolvany); //kiir�s
			}
			rs.close();
		}catch(SQLException e) {
			System.out.println("ReadDataFogyaszto: "+e.getMessage());
		}
		DisConnect(conn);
	}
	
	public void ReadDataSzekhely() {
		String Varos="", Utca="", x="\t";
		int Tid=0,Irsz=0, Hazszam=0;
		String sqlp="SELECT Tid, Irsz, Varos, Utca, Hazszam FROM Szekhely";
		Connection conn = Connect();
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sqlp);
			while(rs.next()) {
				Tid= rs.getInt("Tid");
				Irsz= rs.getInt("Irsz");
				Hazszam= rs.getInt("Hazszam");
				Varos = rs.getString("Varos");  //Adatok beolvas�sa rekordonk�nt ciklusba
				Utca = rs.getString("Utca");
			
				System.out.println(Tid+x+Irsz+x+Varos+x+Utca+x+Hazszam); //kiir�s
			}
			rs.close();
		}catch(SQLException e) {
			System.out.println("ReadDataSzekhely: "+e.getMessage());
		}
		DisConnect(conn);
	}
	
	public void DeleteDataFromFogyasztok() {
		Connection conn = Connect();
		System.out.println("Rekord t�rl�se fogyaszt� ID alapj�n: ");
		String fid = ReadData("K�rem a fogyaszt� ID-j�t: ");
		String sqlp = "DELETE From Fogyasztok WHERE Fid = '"+ fid +"'";
		try {
			Statement s = conn.createStatement();
			int db = s.executeUpdate(sqlp);
			if (db == 0) System.out.println("A megadott ID-val rendelkez� fogyaszt� nem l�tezik, ez�rt nem t�r�lhet�!");
			else System.out.println("T�rl�d�tt a(z) " + fid + " ID-val rendelkez� fogyaszt�!");
		} catch (SQLException e) {
			System.out.println("JDBC DeleteDataFromFogyasztok: "+ e.getMessage());
		} DisConnect(conn);
	}
	
	public void DeleteDataFromCeg() {
		Connection conn = Connect();
		System.out.println("Rekord t�rl�se c�g ID alapj�n: ");
		String cid = ReadData("K�rem a c�g ID-j�t: ");
		String sqlp = "DELETE From Ceg WHERE cid = '"+ cid +"'";
		try {
			Statement s = conn.createStatement();
			int db = s.executeUpdate(sqlp);
			if (db == 0) System.out.println("A megadott ID-val rendelkez� c�g nem l�tezik, ez�rt nem t�r�lhet�!");
			else System.out.println("T�rl�d�tt a(z) " + cid + " ID-val rendelkez� c�g!");
		} catch (SQLException e) {
			System.out.println("JDBC DeleteDataFromCeg: "+ e.getMessage());
		} DisConnect(conn);
	}
	
	public void DeleteDataFromSzekhely() {
		Connection conn = Connect();
		System.out.println("Rekord t�rl�se sz�khely ID alapj�n: ");
		String tid = ReadData("K�rem a sz�khely ID-j�t: ");
		String sqlp = "DELETE From Szekhely WHERE tid = '"+ tid +"'";
		try {
			Statement s = conn.createStatement();
			int db = s.executeUpdate(sqlp);
			if (db == 0) System.out.println("A megadott ID-val rendelkez� sz�khely nem l�tezik, ez�rt nem t�r�lhet�!");
			else System.out.println("T�rl�d�tt a(z) " + tid + " ID-val rendelkez� sz�khely!");
		} catch (SQLException e) {
			System.out.println("JDBC DeleteDataFromSzekhely: "+ e.getMessage());
		} DisConnect(conn);
	}
	
	

public void UpdateDataCeg()
	{
		Connection conn = Connect();
		System.out.println("Rekord m�dos�t�sa c�g ID alapj�n: ");
		String id = ReadData("K�rem a c�g ID-j�t: ");
		String mezo = ReadData("K�rem a m�dos�tani k�v�nt mez� nev�t: ");
		String ujertek = ReadData("K�rem az �rt�ket, amelyre m�dos�tani szeretn� a r�git: ");
		String sqlp = "UPDATE Ceg SET " + mezo + " = " + ujertek + " WHERE cid = '" + id + "'";  
		try {
			Statement s = conn.createStatement();
			int db = s.executeUpdate(sqlp);
			if (db == 0) System.out.println("A m�dos�t�st nem lehet v�grehajtani!");
			else System.out.println("A m�dos�t�s megt�rt�nt, az adott ID-val rendelkez� c�gn�l a(z) " + mezo + " �j �rt�ke " + ujertek);
		}catch (SQLException e) {
			System.out.println("JDBC UpdateDataCeg: " + e.getMessage());
		} DisConnect(conn);
	}
	
	public void UpdateDataSzekhely()
	{
		Connection conn = Connect();
		System.out.println("Rekord m�dos�t�sa sz�khely ID alapj�n: ");
		String id = ReadData("K�rem a sz�khely ID-j�t: ");
		String mezo = ReadData("K�rem a m�dos�tani k�v�nt mez� nev�t: ");
		String ujertek = ReadData("K�rem az �rt�ket, amelyre m�dos�tani szeretn� a r�git: ");
		String sqlp = "UPDATE Szekhely SET " + mezo + " = " + ujertek + " WHERE tid = '" + id + "'";  
		try {
			Statement s = conn.createStatement();
			int db = s.executeUpdate(sqlp);
			if (db == 0) System.out.println("A m�dos�t�st nem lehet v�grehajtani!");
			else System.out.println("A m�dos�t�s megt�rt�nt, az adott ID-val rendelkez� sz�khelyn�l a(z) " + mezo + " �j �rt�ke " + ujertek);
		}catch (SQLException e) {
			System.out.println("JDBC UpdateDataSzekhely: " + e.getMessage());
		} DisConnect(conn);
	}
	
	public void UpdateDataFogyasztok()
	{
		Connection conn = Connect();
		System.out.println("Rekord m�dos�t�sa fogyaszt� ID alapj�n: ");
		String id = ReadData("K�rem a fogyaszt� ID-j�t: ");
		String mezo = ReadData("K�rem a m�dos�tani k�v�nt mez� nev�t: ");
		String ujertek = ReadData("K�rem az �rt�ket, amelyre m�dos�tani szeretn� a r�git: ");
		String sqlp = "UPDATE Fogyasztok SET " + mezo + " = " + ujertek + " WHERE fid = '" + id + "'";  
		try {
			Statement s = conn.createStatement();
			int db = s.executeUpdate(sqlp);
			if (db == 0) System.out.println("A m�dos�t�st nem lehet v�grehajtani!");
			else System.out.println("A m�dos�t�s megt�rt�nt, az adott ID-val rendelkez� fogyaszt�n�l a(z) " + mezo + " �j �rt�ke " + ujertek);
		}catch (SQLException e) {
			System.out.println("JDBC UpdateDataFogyasztok: " + e.getMessage());
		} DisConnect(conn);
	}
	
	public void InsertIntoFogyasztok() {
		
		int check = -1;
		int checkMore = -1;
		String szulonev = null, gyermeknev = null, foglalkozas = null, fid = null, diakigazolvany = null;
		Connection conn = Connect();
		
		System.out.println("Rekord adatainak beolvas�sa, rekord besz�r�sa a fogyaszt�k t�bl�ba:");
		
		
			try {
				Statement s = conn.createStatement();
				
				do{
					fid = ReadData("K�rem a fogyaszt� ID-j�t: ");
					check = s.executeUpdate("SELECT fid FROM Fogyasztok WHERE fid = '"+ fid +"'");
					if(check == 1) System.out.println("M�r l�tezik ilyen ID-val rendelkez� fogyaszt�!");
				}while(check != 0);
								
					szulonev = ReadData("K�rem a fogyaszt� sz�l�j�nek a nev�t: ");
					gyermeknev = ReadData("K�rem a fogyaszt� nev�t: ");
					foglalkozas = ReadData("K�rem a fogyaszt� foglalkoz�s�t: ");
					
				
				do{
					diakigazolvany = ReadData("K�rem a fogyaszt� di�kigazolv�ny�t: ");
					check = s.executeUpdate("SELECT fid FROM Fogyasztok WHERE fid = '"+ fid +"'");
					if(check == 1) System.out.println("M�r l�tezik ilyen ID-val rendelkez� fogyaszt�!");
					checkMore = diakigazolvany.length();
					//System.out.println(checkMore);
					if(checkMore != 11) System.out.println("A di�kigazolv�ny 11 sz�mjegyb�l �ll!");
				}while(check != 0 || checkMore != 11);
					
					String sqlp = "INSERT INTO Fogyasztok Values ("+fid+", '"+ szulonev +"', '"+ gyermeknev + "', '" + foglalkozas + "', " + diakigazolvany + ")";
					s.execute(sqlp);
					
					System.out.println("A rekord besz�r�sa megt�rt�nt!");
				} catch(SQLException e) {
					System.out.println("JDBC InsertIntoFogyasztok: " + e.getMessage());
				} DisConnect(conn);
		}
	
	public void InsertIntoCeg() {
		
		int check = -1;
		String cid = null, tid = null, fid = null, nev = null, alapitas = null;
		Connection conn = Connect();
		
		System.out.println("Rekord adatainak beolvas�sa, rekord besz�r�sa a c�g t�bl�ba:");
		
		
			try {
				Statement s = conn.createStatement();
				int checkMore;
				
				do{
					cid = ReadData("K�rem a c�g ID-j�t: ");
					check = s.executeUpdate("SELECT cid FROM Ceg WHERE cid = "+ cid);
					if(check == 1) System.out.println("M�r l�tezik ilyen ID-val rendelkez� c�g!");
				}while(check != 0);
				
				do {
					checkMore = 0;
					
					do{
						tid = ReadData("K�rem a sz�khely ID-j�t: ");
						check = s.executeUpdate("SELECT tid FROM Szekhely WHERE tid = " + tid);
						if(check == 0) System.out.println("Nem l�tezik ilyen ID-val rendelkez� sz�khely!");
					}while(check != 1);
					
					do {
						fid = ReadData("K�rem a fogyaszt� ID-j�t: ");
						check = s.executeUpdate("SELECT fid FROM Fogyasztok WHERE fid = " + fid);
						if(check==0) System.out.println("Nem l�tezik ilyen ID-val rendelkez� fogyaszt�!");
					}while(check!=1);
					
					checkMore = s.executeUpdate("SELECT tid, fid FROM Ceg WHERE tid = " + tid + " AND fid = " + fid);
					if(checkMore==1) System.out.println("E k�z�tt a sz�khely �s fogyaszt� k�z�tt m�r l�tezik kapcsolat!");
					
				}while(checkMore!=0);			
				
				
				do {
					
					nev = ReadData("K�rem a c�g nev�t: ");
					
					check = s.executeUpdate("SELECT nev FROM Ceg WHERE nev = '"+ nev + "'");
					
					if (check == 1) System.out.println("Ilyen n�vvel m�r van felv�ve c�g az adatb�zisba!");
					
				}while(check != 0);
				
				alapitas = ReadData("K�rem az alap�t�s d�tum�t: (a d�tumot k�rlek ilyen form�ban add meg: 2015-05-10)");
					
					String sqlp = "INSERT INTO Ceg Values ("+ cid +", "+ tid +", "+ fid + ", '" + nev + "', TO_DATE('" + alapitas + "', 'YYYY-MM-DD'))";
					s.execute(sqlp);
					System.out.println("A rekord besz�r�sa megt�rt�nt!");
				} catch(SQLException e) {
					System.out.println("JDBC InsertIntoCeg: " + e.getMessage());
				} DisConnect(conn);
		}
	
	public void InsertIntoSzekhely() {
		
		int check = -1;
		String tid = null, irsz = null, varos = null, utca = null, hazszam = null;
		Connection conn = Connect();
		
		System.out.println("Rekord adatainak beolvas�sa, rekord besz�r�sa a Sz�khely t�bl�ba:");
		
		
			try {
				Statement s = conn.createStatement();
				
				do{
					tid = ReadData("K�rem a sz�khely ID-j�t: ");
					check = s.executeUpdate("SELECT tid FROM Szekhely WHERE tid = "+ tid);
					if(check == 1) System.out.println("M�r l�tezik ilyen ID-val rendelkez� sz�khely!");
				}while(check != 0);
					
				
				do {
					irsz = ReadData("K�rem a sz�khely ir�ny�t�sz�m�t: ");
					varos = ReadData("K�rem a sz�khely v�ros�t: ");
					utca = ReadData("K�rem a sz�khely utc�j�t: ");
					hazszam = ReadData("K�rem a sz�khely h�zsz�m�t: ");
					
					check = s.executeUpdate("SELECT irsz, varos, utca, hazszam FROM Szekhely WHERE irsz = "+ irsz + ", varos = '" 
					+ varos + "', utca = '" + utca + "', hazszam = " + hazszam );
					if (check == 1) System.out.println("Ez a sz�khely m�r fel van v�ve az adatb�zisba egy m�sik ID-val!");
				}while(check != 0);
					
					String sqlp = "INSERT INTO Szekhely Values ("+tid+", "+ irsz +", '"+ varos + "', '" + utca + "', " + hazszam + ")";
					s.execute(sqlp);
					System.out.println("A rekord besz�r�sa megt�rt�nt!");
				} catch(SQLException e) {
					System.out.println("JDBC InsertIntoSzekhely: " + e.getMessage());
				} DisConnect(conn);
		}
	
	
	public void menu() {
		System.out.println("\n");
		System.out.println("MEN�:");
		System.out.println("\n");

		
		int m, n;
		int ok;
		
		do{
			ok = 0;
			System.out.println("Melyik t�bl�val szeretn�l foglalkozni?");
			System.out.println("\n");
			System.out.println("0 Kil�p�s");
			System.out.println("1 Fogyaszt�k");
			System.out.println("2 Sz�khely");
			System.out.println("3 C�g");
			
			m = ReadInt("Add meg a v�lasztott t�bla sz�m�t: ");
			
			if(m>-1 && m<4) ok = 1;
			else System.out.println("K�rlek a felsorolt sz�mok k�z�l v�lassz!");
		}while(ok != 1);
		
		if (m == 0) 
		{
			System.out.println("A program le�llt!");
			System.exit(0);
		}
		
		do {
			ok = 0;
			System.out.println("Milyen m�veletet szeretn�l v�gezni a t�bl�n?");
			System.out.println("\n");
			System.out.println("0 Kil�p�s");
			System.out.println("1 List�z�s");
			System.out.println("2 Besz�r�s");
			System.out.println("3 T�rl�s");
			System.out.println("4 M�dos�t�s");
			
			n = ReadInt("Add meg a v�lasztott m�velet sz�m�t?");
			
			if(n>=-1 && n<5) ok=1;
			else System.out.println("K�rlek a felsorolt sz�mok k�z�l v�lassz!");
		}while (ok != 1);
		
		if(n == 0)
		{
			System.out.println("A program le�llt!");
			System.exit(0);
		}
		else
		{
			m = m*10 + n;
			
			switch(m)
			{
				case 11: ReadDataFogyaszto(); break;
				case 12: InsertIntoFogyasztok(); break;
				case 13: DeleteDataFromFogyasztok(); break;
				case 14: UpdateDataFogyasztok(); break;
				case 21: ReadDataSzekhely(); break;
				case 22: InsertIntoSzekhely(); break;
				case 23: DeleteDataFromSzekhely(); break;
				case 24: UpdateDataSzekhely(); break;
				case 31: ReadDataCeg(); break;
				case 32: InsertIntoCeg(); break;
				case 33: DeleteDataFromCeg(); break;
				case 34: UpdateDataCeg(); break;
				
			}
			
		}
		
	}
	
	
	
	
	
}
